class Stack():
    def __init__(self):  # Initialize a new stack
        self._items = []
        self._size = 0
        self._top = -1

    def push(self, new_item):  #  Append the new item to the stack 
        self._items.append(new_item)
        self._top += 1
        self._size += 1
        self._items[self._top] = new_item

    def pop(self):  # Remove and return the last item from the stack
        old_item = self._items[self._top]
        self._top -= 1
        self._size -= 1
        return old_item

    def size(self):  # Return the total number of elements in the stack
       return len(self._items)

    def isEmpty(self):  #  Return True if the stack is empty and False if it is not empty 
        if self._items == 0:
            return True
        else:
            return False

    def peek(self):   # Return the element at the top of the stack or return None if the stack is 
        if self.isEmpty():
            return None
        else:
            return self._items[self._top]
def check(myStr):
    open_list = ["[","{","("]
    close_list = ["]","}",")"]
    stack = []
    for i in myStr:
        if i in open_list:
            stack.append(i)
        elif i in close_list:
            pos = close_list.index(i)
            if ((len(stack) > 0) and
                (open_list[pos] == stack[len(stack)-1])):
                stack.pop()
            else:
                return "Unbalanced"
    if len(stack) == 0:
        return "Balanced"
    else:
        return "Unbalanced"
exp1 = "(2)+(-5)" # True
exp2 = "((2))*((3))" # True
exp3 = "(4))]" #False

print(check(exp2))
print(check(exp1))
print(check(exp3))
