class Demo_Stack:
 
    def __init__(self):
        self.demo_stack = list()
        self.maximumSize = 5
        self.top_of_the_stack = 0
 
    # Insert the  element to the Stack
 
    def push(self,element):
            if self.top_of_the_stack>=self.maximumSize:
                return ( " The given stack is full! " )
            self.demo_stack.append(element)
            self.top_of_the_stack += 1
            return True
     
# Delete the element from the stack
     
    def pop(self):
            if self.top_of_the_stack<=0:
                return ( " The given stack is empty! " )
            item = self.demo_stack.pop()
            self.top_of_the_stack -= 1
            return item
 
    def size(self):
            return self.top_of_the_stack
 
demo_data = Demo_Stack()
 
print(demo_data.push(10)) # prints True
 
print(demo_data.push(20)) # prints True
 
print(demo_data.push(30)) # prints True
 
print(demo_data.push(40)) # prints True
 
print(demo_data.push(50)) # prints True
 
print(demo_data.push(60)) # prints True
 
print(demo_data.push(70)) # prints True
 
print(demo_data.push(80)) # prints True
 
print(demo_data.push(90)) # prints Stack Full!
 
print(demo_data.size()) # prints 8   
 
print(demo_data.pop()) # prints 80
 
print(demo_data.pop()) # prints 70
 
print(demo_data.pop()) # prints 60
 
print(demo_data.pop()) # prints 50
 
print(demo_data.pop()) # prints 40
 
print(demo_data.pop()) # prints 30
 
print(demo_data.pop()) # prints 20
 
print(demo_data.pop()) # prints 10
 
print(demo_data.pop()) # prints Stack is Empty!
 
