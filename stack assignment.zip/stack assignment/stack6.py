def Transfer(S, T):

 #set for loop  

 for i in range(len(S)):

   #append in the list

   T.append(S.pop())

 #return the value of the list

 return T

#set list type variable

S = ["a","b","c","d"]

#print the values of the list

print(S)

#set the list empty type variable

T=[]

#call the function

T = Transfer(S, T)

#print the value of T

print(T)

